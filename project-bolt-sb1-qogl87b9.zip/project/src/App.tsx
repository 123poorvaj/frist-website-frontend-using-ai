import React from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import IntroSection from './components/IntroSection';
import SoundFamiliar from './components/SoundFamiliar';
import TherapistIntro from './components/TherapistIntro';
import Services from './components/Services';
import Footer from './components/Footer';
import { AnimatePresence } from 'framer-motion';

function App() {
  return (
    <div className="min-h-screen bg-haven-cream">
      <AnimatePresence>
        <Header />
        <main>
          <Hero />
          <IntroSection />
          <SoundFamiliar />
          <TherapistIntro />
          <Services />
        </main>
        <Footer />
      </AnimatePresence>
    </div>
  );
}

export default App;