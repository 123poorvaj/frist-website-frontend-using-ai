import React, { useState, useEffect } from 'react';
import { Menu, X } from 'lucide-react';
import { motion } from 'framer-motion';

const Header = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 50) {
        setScrolled(true);
      } else {
        setScrolled(false);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const toggleMenu = () => {
    setIsOpen(!isOpen);
  };

  return (
    <motion.header 
      className={`fixed w-full z-50 transition-all duration-300 ${
        scrolled ? 'bg-haven-cream shadow-md py-2' : 'bg-transparent py-4'
      }`}
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <div className="container mx-auto px-4 flex justify-between items-center">
        <a href="/" className="text-xl font-serif tracking-wider uppercase">Haven</a>
        
        {/* Desktop Navigation */}
        <nav className="hidden md:flex space-x-8">
          <a href="#about" className="nav-link">About</a>
          <a href="#approach" className="nav-link">Approach</a>
          <a href="#services" className="nav-link">Services</a>
          <a href="#pricing" className="nav-link">Pricing</a>
          <a href="#contact" className="btn-primary">Schedule a Free Consultation</a>
        </nav>
        
        {/* Mobile Menu Button */}
        <button className="md:hidden" onClick={toggleMenu}>
          {isOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>
      
      {/* Mobile Navigation */}
      {isOpen && (
        <motion.div 
          className="md:hidden bg-haven-cream absolute top-full left-0 w-full shadow-md"
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: 'auto' }}
          exit={{ opacity: 0, height: 0 }}
          transition={{ duration: 0.3 }}
        >
          <div className="container mx-auto px-4 py-4 flex flex-col space-y-4">
            <a href="#about" className="nav-link py-2" onClick={toggleMenu}>About</a>
            <a href="#approach" className="nav-link py-2" onClick={toggleMenu}>Approach</a>
            <a href="#services" className="nav-link py-2" onClick={toggleMenu}>Services</a>
            <a href="#pricing" className="nav-link py-2" onClick={toggleMenu}>Pricing</a>
            <a href="#contact" className="btn-primary text-center" onClick={toggleMenu}>Schedule a Free Consultation</a>
          </div>
        </motion.div>
      )}
    </motion.header>
  );
};

export default Header;