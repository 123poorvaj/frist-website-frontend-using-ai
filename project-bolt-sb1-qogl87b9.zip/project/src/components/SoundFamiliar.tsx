import React from 'react';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { ArrowRight } from 'lucide-react';
import FamiliarItem from './common/FamiliarItem';

const SoundFamiliar = () => {
  const { ref, inView } = useInView({
    threshold: 0.1,
    triggerOnce: true
  });

  const containerVariants = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2
      }
    }
  };

  return (
    <section className="py-16 bg-haven-sage text-white" id="approach">
      <div className="container mx-auto" ref={ref}>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
          <div className="order-2 md:order-1">
            <img 
              src="https://images.pexels.com/photos/6707628/pexels-photo-6707628.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" 
              alt="Cozy living space with plants and a cup of coffee" 
              className="rounded-lg shadow-md w-full h-auto object-cover"
            />
          </div>
          
          <motion.div 
            className="order-1 md:order-2"
            initial={{ opacity: 0 }}
            animate={inView ? { opacity: 1 } : { opacity: 0 }}
            transition={{ duration: 0.5 }}
          >
            <h2 className="text-3xl font-serif mb-8">Sound familiar?</h2>
            
            <motion.div
              variants={containerVariants}
              initial="hidden"
              animate={inView ? "show" : "hidden"}
              className="space-y-6"
            >
              <FamiliarItem>
                I find myself stuck in painful, uncomfortable relationship patterns with my parents. I believe some of these wounds may be getting triggered in my current relationships.
              </FamiliarItem>
              
              <FamiliarItem>
                I want to develop a better relationship with myself, especially in times of distress. I find myself unable to self-soothe when my nervous system feels activated.
              </FamiliarItem>
              
              <FamiliarItem>
                I'm realizing I need to set strong boundaries with my family members. I feel stuck in unhealthy patterns with my closest relationships.
              </FamiliarItem>
              
              <FamiliarItem>
                I feel stuck between perfectionism and shame. I struggle to feel worthy and lovable unless I'm constantly achieving. I'm ready to break free.
              </FamiliarItem>
            </motion.div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default SoundFamiliar;