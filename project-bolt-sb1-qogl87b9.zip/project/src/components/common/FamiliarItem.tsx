import React from 'react';
import { motion } from 'framer-motion';
import { ArrowRight } from 'lucide-react';

interface FamiliarItemProps {
  children: React.ReactNode;
}

const FamiliarItem = ({ children }: FamiliarItemProps) => {
  const itemVariants = {
    hidden: { opacity: 0, x: -10 },
    show: { opacity: 1, x: 0 }
  };

  return (
    <motion.div 
      className="flex items-start"
      variants={itemVariants}
      transition={{ duration: 0.4 }}
    >
      <ArrowRight size={20} className="mt-1 mr-4 flex-shrink-0" />
      <p className="text-base leading-relaxed">{children}</p>
    </motion.div>
  );
};

export default FamiliarItem;