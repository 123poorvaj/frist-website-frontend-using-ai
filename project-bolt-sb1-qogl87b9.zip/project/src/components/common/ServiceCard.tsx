import React from 'react';
import { motion } from 'framer-motion';
import { ArrowRight } from 'lucide-react';

interface ServiceCardProps {
  title: string;
  children: React.ReactNode;
  icon: React.ReactNode;
  delay?: number;
}

const ServiceCard = ({ title, children, icon, delay = 0 }: ServiceCardProps) => {
  const cardVariants = {
    hidden: { opacity: 0, y: 20 },
    show: { 
      opacity: 1, 
      y: 0,
      transition: {
        duration: 0.5,
        delay: delay
      }
    }
  };

  return (
    <motion.div 
      className="bg-white p-8 rounded-lg shadow-md"
      variants={cardVariants}
    >
      <div className="mb-4">
        {icon}
      </div>
      <h3 className="text-xl font-serif mb-4">{title}</h3>
      <p className="text-base leading-relaxed mb-6">
        {children}
      </p>
      <motion.a 
        href="#contact" 
        className="text-haven-sage inline-flex items-center text-sm font-medium"
        whileHover={{ x: 5 }}
        transition={{ duration: 0.2 }}
      >
        Learn More
        <ArrowRight size={16} className="ml-2" />
      </motion.a>
    </motion.div>
  );
};

export default ServiceCard;