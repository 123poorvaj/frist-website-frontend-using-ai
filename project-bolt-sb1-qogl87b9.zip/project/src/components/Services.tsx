import React from 'react';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import ServiceCard from './common/ServiceCard';
import { Heart, Brain, Hourglass } from 'lucide-react';

const Services = () => {
  const { ref, inView } = useInView({
    threshold: 0.1,
    triggerOnce: true
  });

  const containerVariants = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2
      }
    }
  };

  return (
    <section className="py-16 md:py-24 bg-haven-cream" id="services">
      <div className="container mx-auto" ref={ref}>
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
          transition={{ duration: 0.6 }}
        >
          <h2 className="section-title mb-4">How I Can Help</h2>
        </motion.div>
        
        <motion.div 
          className="grid grid-cols-1 md:grid-cols-3 gap-8"
          variants={containerVariants}
          initial="hidden"
          animate={inView ? "show" : "hidden"}
        >
          <ServiceCard 
            title="EMDR Therapy" 
            icon={<Brain className="w-8 h-8 text-haven-sage" />}
            delay={0}
          >
            EMDR (Eye Movement Desensitization and Reprocessing) is a powerful psychotherapy approach that helps people heal from trauma or distressing life experiences.
          </ServiceCard>
          
          <ServiceCard 
            title="Somatic Therapy" 
            icon={<Heart className="w-8 h-8 text-haven-sage" />}
            delay={0.2}
          >
            Somatic therapy focuses on the connection between mind and body, helping release physical tension that may be related to repressed emotions and trauma.
          </ServiceCard>
          
          <ServiceCard 
            title="Grief & Loss" 
            icon={<Hourglass className="w-8 h-8 text-haven-sage" />}
            delay={0.4}
          >
            Through compassionate guidance, I help clients navigate the complex emotions of grief and loss, honoring their unique journey toward healing.
          </ServiceCard>
        </motion.div>
      </div>
    </section>
  );
};

export default Services;