import React from 'react';
import { motion } from 'framer-motion';
import { Mail, Phone, MapPin, Instagram, Facebook, Twitter } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-haven-dark text-white py-16" id="contact">
      <div className="container mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="col-span-1 md:col-span-2">
            <h3 className="text-2xl font-serif mb-4">Haven</h3>
            <p className="mb-6 text-gray-300 max-w-md">
              Creating a safe space for healing, growth, and transformation. Online therapy services available throughout California.
            </p>
            <div className="flex space-x-4">
              <motion.a 
                href="#" 
                whileHover={{ y: -3 }}
                className="text-white hover:text-haven-sage transition-colors duration-200"
              >
                <Instagram size={20} />
              </motion.a>
              <motion.a 
                href="#" 
                whileHover={{ y: -3 }}
                className="text-white hover:text-haven-sage transition-colors duration-200"
              >
                <Facebook size={20} />
              </motion.a>
              <motion.a 
                href="#" 
                whileHover={{ y: -3 }}
                className="text-white hover:text-haven-sage transition-colors duration-200"
              >
                <Twitter size={20} />
              </motion.a>
            </div>
          </div>
          
          <div>
            <h4 className="text-lg font-medium mb-4">Contact</h4>
            <ul className="space-y-3">
              <li className="flex items-center">
                <Mail size={16} className="mr-2 text-haven-sage" />
                <a href="mailto:hello@haventherapy.com" className="text-gray-300 hover:text-white transition-colors duration-200">
                  hello@haventherapy.com
                </a>
              </li>
              <li className="flex items-center">
                <Phone size={16} className="mr-2 text-haven-sage" />
                <a href="tel:+15551234567" className="text-gray-300 hover:text-white transition-colors duration-200">
                  (555) 123-4567
                </a>
              </li>
              <li className="flex items-start">
                <MapPin size={16} className="mr-2 mt-1 text-haven-sage" />
                <span className="text-gray-300">
                  Virtual sessions available throughout California
                </span>
              </li>
            </ul>
          </div>
          
          <div>
            <h4 className="text-lg font-medium mb-4">Quick Links</h4>
            <ul className="space-y-2">
              <li>
                <a href="#about" className="text-gray-300 hover:text-white transition-colors duration-200">About</a>
              </li>
              <li>
                <a href="#services" className="text-gray-300 hover:text-white transition-colors duration-200">Services</a>
              </li>
              <li>
                <a href="#" className="text-gray-300 hover:text-white transition-colors duration-200">Blog</a>
              </li>
              <li>
                <a href="#" className="text-gray-300 hover:text-white transition-colors duration-200">FAQ</a>
              </li>
              <li>
                <a href="#" className="text-gray-300 hover:text-white transition-colors duration-200">Privacy Policy</a>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-gray-700 mt-12 pt-8 text-center text-gray-400 text-sm">
          <p>&copy; {new Date().getFullYear()} Haven Therapy. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;