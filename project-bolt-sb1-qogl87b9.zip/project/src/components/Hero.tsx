import React from 'react';
import { motion } from 'framer-motion';
import { ArrowRight } from 'lucide-react';

const Hero = () => {
  return (
    <section className="pt-24 pb-16 md:py-32">
      <div className="container mx-auto grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.6 }}
          className="order-2 md:order-1"
        >
          <p className="uppercase text-sm tracking-widest text-haven-sage mb-2">Online Trauma Therapy in California</p>
          <h1 className="section-title mb-4">
            Create Your Haven:<br />
            Embrace <em>Change</em>,<br />
            Discover <em>Yourself</em>
          </h1>
          <motion.a 
            href="#contact" 
            className="btn-primary mt-6 inline-flex items-center"
            whileHover={{ scale: 1.03 }}
            whileTap={{ scale: 0.98 }}
          >
            Schedule a Free Consultation
            <ArrowRight size={16} className="ml-2" />
          </motion.a>
        </motion.div>
        
        <motion.div 
          className="order-1 md:order-2"
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
        >
          <img 
            src="https://images.pexels.com/photos/5699456/pexels-photo-5699456.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" 
            alt="Therapist working with client" 
            className="rounded-lg shadow-lg w-full h-auto object-cover"
          />
        </motion.div>
      </div>
    </section>
  );
};

export default Hero;